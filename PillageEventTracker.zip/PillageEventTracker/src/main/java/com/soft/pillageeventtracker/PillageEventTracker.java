package com.soft.pillageeventtracker;

import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.raid.RaidTriggerEvent;
import org.bukkit.Location;
import me.clip.placeholderapi.PlaceholderAPI;

public final class PillageEventTracker extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info( "[PillageEventTracker] 插件已启用.");
    }

    @Override
    public void onDisable() {
        getLogger().info( "[PillageEventTracker] 插件已禁用.");
    }

    @EventHandler
    public void onRaidTrigger(RaidTriggerEvent event) {
        Location raidLocation = event.getRaid().getLocation();

        // 从配置文件获取Y轴高度限制
        double yAxisLimit = getConfig().getDouble("raid-y-axis-limit", 100);

        if (raidLocation.getY() <= yAxisLimit) {
            String playerName = event.getPlayer().getName();
            // 使用PlaceholderAPI获取玩家坐标
            String playerCoords = PlaceholderAPI.setPlaceholders(event.getPlayer(), "X:%player_x%, Y:%player_y%, Z:%player_z%");

            String message = getConfig().getString("pillage-message", playerName + " 触发了一次事件在: " + playerCoords);
            message = message.replace("{player}", playerName).replace("{location}", playerCoords);

            String consoleMessage = ChatColor.stripColor(message);

            getLogger().info(consoleMessage);
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("pillageeventtracker")) {
            if (sender.hasPermission("pillageeventtracker.reload")) {
                reloadConfig();
                sender.sendMessage( "配置文件已重载。");
            } else {
                sender.sendMessage( "你没有执行这个命令的权限。");
            }
            return true;
        } else {
            return false;
        }
    }
}